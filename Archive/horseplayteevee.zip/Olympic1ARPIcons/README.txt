Olympic1 ARP Icons - v0.7.2
---------------------------
Add icons to popular mods!

By Olympic1

Forum thread for latest: http://forum.kerbalspaceprogram.com/threads/102980

INSTALLATION
------------
Installing the icons involves copying the icon files into the correct location in the KSP application folder
1. Extract the .zip file you have downloaded to a temporary location
2. Open the extracted folder structure and open the Olympic1ARPIcons_v0.7.2 folder
3. Inside this you will find a GameData folder which contains all the content you will need
4. Open another window to your KSP application folder - We'll call this <KSP_OS>
5. Copy the contents of the extracted GameData folder to the <KSP_OS>\GameData folder
6. Start the game and enjoy your new icons

LICENSE
-------
This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
See http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode for full details.

Copyright © 2014 - 2015, Olympic1 ( http://github.com/Olympic1 )

-----

You are free to:

Share - Copy and redistribute the material in any medium or format.
Adapt - Remix, transform, and build upon the material.

Under the following terms:

Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
NonCommercial - You may not use the material for commercial purposes.
ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
No additional restrictions - You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

VERSION HISTORY
---------------
See the CHANGELOG.txt file